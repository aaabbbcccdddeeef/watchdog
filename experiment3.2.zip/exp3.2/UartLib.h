/*
 * UartLib.h
 *  v1.0
 *  Created on: 2019年3月9日
 *      Author: 刘夏越
 *              徐一泓
 *              
 */

#ifndef UARTLIB_H_
#define UARTLIB_H_

#include <msp430f5529.h>
#include "driverlib.h"

#define BAUD_RATE                               9600 //ok:256000,115200,57600,38400,19200,9600
#define RECEIVE_DATA_COUNT                      0x02
#define UART_BUF                                100  //发送/接收缓冲区最大值
#define USCI_A_UART_MULTIPROCESSOR_MODE_ADDRESS 0xAA

extern uint8_t receivedData;
extern uint8_t receiveDataCount;
extern uint8_t transmitData;
extern uint8_t receivedBuf[UART_BUF];  //串口接收的是字符数组
extern uint8_t receivedBufIndex;
extern char sendBuf[UART_BUF];
extern uint8_t check;


void UartA1_Init();  //初始化

void uartA1_send(uint8_t *data); //发送char数组

void uartA1_clearRxBuf(); //清空接收数组

int uartA1_printf(const char *fmt, ...); //发送格式化字符串，跟printf用法一样

int uartA1_scanf(const char *fmt, ...); //格式化输入，和scanf用法一样，会等待串口输入

int uartA1_scanfBuf(const char *fmt, ...);//格式化输入，直接从receivedBuf读

void delay_ms(unsigned long ms);//delay，外部函数，位于main.h中


#endif /* UARTLIB_H_ */
